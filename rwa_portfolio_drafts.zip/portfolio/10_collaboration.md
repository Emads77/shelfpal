# Show and tell: Collaboration

**Learning outcome:** You evaluate the performance of your group and its individual members in an open, honest, and substantiated manner.
**Rubric row:** Collaboration (5%)

## How the work was divided

| Area | Emad | Andrea |
| --- | --- | --- |
| Research and MCAs | [TO FILL] | [TO FILL] |
| Target audience survey | [TO FILL] | Ran the Google Form |
| Backend features | Add a book manually (#53), scan and Open Library lookup (#51) | Search (#62), extra copy details and detail page (MR !15), edit and reading status (MR !17) |
| Frontend features | Add book page, scan page | Search, book detail, status menu, edit page |
| Security | Ownership rules, audit request | [TO FILL] |
| Deployment pipeline and HTTPS | Images in CI (#71), server stack (#72), Caddy and firewall (#83), automated deploy (#85), seeding (#40) | Monitoring config in the deploy, Faro build argument |
| Update strategy | Rolling backends (#70) and frontends (#86), version banner | [TO FILL] |
| Monitoring | Review | Logging, Faro, Alloy, dashboard and alerts (#63) |
| Offline | Read only PWA (#91) | Raised the PWA idea |
| Tests | Component tests, end to end tests, traceability matrix | Backend tests in his MRs |
| API documentation | | OpenAPI file and docs page |

Proof: GitLab issues, merge requests and commit history. [TO FILL: link to the contributors graph]

## What I understand of my partner's work

### Emad about Andrea's work

[TO FILL: explain in your own words how the request id travels from browser to Grafana, and how copy on write works in update_copy]

### Andrea about Emad's work

[TO FILL: explain in your own words how a rolling deploy keeps the app online, and how production gets the tested image]

## Reflection

### Emad

* **My contribution:** [TO FILL]
* **What went well:** [TO FILL]
* **What did not go well:** [TO FILL]
* **What I would do differently:** [TO FILL]
* **What I want to keep doing:** [TO FILL]

### Andrea

* **My contribution:** [TO FILL]
* **What went well:** [TO FILL]
* **What did not go well:** [TO FILL]
* **What I would do differently:** [TO FILL]
* **What I want to keep doing:** [TO FILL]

### Together

* **Keep:** reviewing every MR before merging, linking commits to issues.
* **Change:** [TO FILL: for example keeping each MR to one story, so reviews stay small and scope stays clear]

## Use of generative AI

This table was drafted with Claude from our issue and MR history. The reflections are our own words.
