# Show and tell: HTTPS and domain

**Learning outcome:** You make your application's environments accessible on a domain via https.
**Rubric row:** HTTPS and domain (5%)
**Main work by:** Emad (#83, environment indicator) [TO FILL: confirm]

## What we built

Both environments have their own domain: https://shelfpal.saxion.college for production and https://acc.shelfpal.saxion.college for acceptance. Caddy runs on the server, gets and renews the certificates by itself, redirects HTTP to HTTPS and spreads traffic over two frontend containers. The app shows which environment you are in and lets you switch.

## Proof

| What | Where to see it |
| --- | --- |
| Caddy configuration | `deploy/Caddyfile` |
| Firewall | `deploy/firewall.sh` |
| Environment badge | `frontend/src/shared/ui/EnvironmentBadge.jsx` and its two tests |
| Screenshot: valid certificate on both domains | [TO FILL: screenshots] |
| Screenshot: acceptance strip and production link | [TO FILL: screenshots] |

## What the assessor looks at

| Assessor looks at | Our answer | Proof |
| --- | --- | --- |
| Both environments on HTTPS with a valid certificate | Yes, Let's Encrypt certificates through Caddy. | Screenshots |
| How certificates are managed and renewed | Caddy requests and renews them automatically, no cron job or manual step. | `deploy/Caddyfile` |
| How the frontend knows its backend | The frontend calls `/api/` on its own domain. nginx inside the frontend container forwards it to the backends of the same stack, so one image serves both environments. [TO FILL: confirm VITE_API_URL is relative] | `frontend/nginx.conf` |
| How a user knows the environment | Acceptance shows a strip "Acceptance environment. Data here is for testing only." with a link to production. Production shows only a small, quiet link to acceptance. Local development shows its own strip. | Screenshots |

## Link to requirements

Confidentiality QR: all traffic is encrypted.

## Decisions and trade offs

* **Caddy on the host instead of in Docker:** one proxy for both stacks, with automatic certificates. Trade off: one more service to keep updated outside the pipeline.
* **Environment chosen from the hostname at runtime:** one image works everywhere. Trade off: a new domain needs a code change.

## Problems we ran into

* **An old service worker from a demo app** made both domains hang in a normal browser window while incognito worked. Fixed by unregistering it and clearing site data.

## What we learned

### Emad

* **Could not do at the start, can do now:** [TO FILL]
* **Would do differently next time:** [TO FILL]
* **Already knew before this course:** [TO FILL]

### Andrea

* **Could not do at the start, can do now:** [TO FILL]
* **Would do differently next time:** [TO FILL]
* **Already knew before this course:** [TO FILL]

## Use of generative AI

Claude helped write the Caddyfile and the environment badge. This document was drafted with Claude from our own project notes and checked by us.
