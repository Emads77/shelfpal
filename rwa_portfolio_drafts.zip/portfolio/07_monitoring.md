# Show and tell: Monitoring

**Learning outcome:** You monitor the stability of your application in production using a monitoring system.
**Rubric row:** Monitoring (15%)
**Main work by:** Andrea (#63 observability) [TO FILL: confirm, and Emad's part]

## What we built

The backend writes one JSON log line per request, with a request id that the browser also logs, so one action can be followed from browser to database. Grafana Alloy runs on the server, reads the container logs and ships them to Grafana Cloud (Loki). The frontend sends its own logs and errors with Grafana Faro. A dashboard and alert rules sit in Grafana Cloud, and `/api/health/` reports whether a backend can reach the database.

## Proof

| What | Where to see it |
| --- | --- |
| Request logging and request id | `backend/config/middleware.py`, `backend/config/log_utils.py` |
| Health endpoint | `/api/health/`, `backend/config/views.py` |
| Frontend logging | `frontend/src/.../logger.js`, `faro.js` [TO FILL: paths] |
| Log shipping | `monitoring/config.alloy` |
| Dashboard and alert exports | `monitoring/` |
| Screenshot: dashboard | [TO FILL] |
| Screenshot: logs filtered by level and by request id | [TO FILL] |
| Screenshot: an alert that fired, and the notification | [TO FILL] |

## What the assessor looks at

| Assessor looks at | Our answer | Proof |
| --- | --- | --- |
| What it covers | Errors (5xx), response times, request volume, frontend errors, backend health. [TO FILL: resource usage or uptime check, if present] | Dashboard |
| Frontend logging | Yes, Faro sends browser logs and uncaught errors directly to Grafana Cloud. | `faro.js` |
| What the dashboard shows | [TO FILL: panels] | Screenshot |
| Problems detected automatically | Error spikes and slow responses. [TO FILL: downtime check on `/api/health/`] | Alert rules |
| Alerting, and when it fires | [TO FILL: rule, threshold, contact point, and the proof it fired] | Screenshot |

## Link to requirements

Performance QR (500 ms for 95% of requests) and availability QR.

## Decisions and trade offs

* **Grafana Cloud instead of hosting Loki ourselves:** no extra containers on a small server. Trade off: logs leave our server.
* **Logs, not metrics, for alerts:** quick to set up. Trade off: a dead backend writes no log lines, so a log based rule stays silent. That needs an outside check on `/api/health/`.

## Problems we ran into

* **Alloy port open to the internet:** found in review, bound to 127.0.0.1.
* **No frontend logs on production:** the Faro URL only existed in the development settings. It is now passed as a build argument.
* **Docker socket:** Alloy needs it to read logs, and a read only mount does not stop it controlling containers. Written down as a known limitation.

## What we learned

### Emad

* **Could not do at the start, can do now:** [TO FILL]
* **Would do differently next time:** [TO FILL]
* **Already knew before this course:** [TO FILL]

### Andrea

* **Could not do at the start, can do now:** [TO FILL]
* **Would do differently next time:** [TO FILL]
* **Already knew before this course:** [TO FILL]

## Use of generative AI

[TO FILL: Andrea's use.] Claude reviewed the observability MR. This document was drafted with Claude from our own project notes and checked by us.
