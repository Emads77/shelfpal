# Show and tell: Update strategy

**Learning outcome:** You employ an update strategy that ensures users experience no disruptions when updates are installed.
**Rubric row:** Update strategy (10%)
**Main work by:** Emad (#70, #86, #40) [TO FILL: confirm]

## What we built

Each environment runs two backends and two frontends. A deploy first runs the migrations in a throwaway container, then replaces the instances one at a time and waits until each is healthy before touching the next, so there is always one serving. A user with an open tab gets a banner offering to reload when a new version is live.

## Proof

| What | Where to see it |
| --- | --- |
| Deploy order | `deploy/deploy.sh` |
| Two backends with health checks | `deploy/docker-compose.server.yaml`, `backend/healthcheck.py` |
| Backend balancing and retry | `frontend/nginx.conf` |
| Frontend balancing with health checks | `deploy/Caddyfile` |
| Version banner | `UpdateBanner`, `version.json` |
| Design and diagrams | Technical design 13.11 |
| Zero failure test during a deploy | [TO FILL: method, number of requests, failures, screenshot] |
| Screenshot: reload banner | [TO FILL] |

## What the assessor looks at

| Assessor looks at | Our answer | Proof |
| --- | --- | --- |
| Noticeable downtime | No: one instance of each keeps serving while the other is replaced. nginx retries a request on the other backend if one fails (`proxy_next_upstream`), and Caddy only sends traffic to frontends that pass the health check. | Zero failure test |
| Migrations | Applied automatically by `deploy.sh` before the new backends start. Because the old backend keeps running on the new schema for a moment, migrations must be additive: add first, remove in a later release. [TO FILL: confirm this policy] | `deploy.sh` |
| Old frontends after a backend update | The banner checks `version.json` every 5 minutes and when the tab comes back, then offers a reload. Until then the old frontend keeps working because API changes are additive. `index.html` is never cached, so a reload always gets the new version. | Banner screenshot |
| How it is implemented | Rolling updates behind nginx (backends) and Caddy (frontends). | 13.11 |
| Controlled releasing of features | Not built. We considered feature flags (django-waffle) and chose not to for this deadline; reasons in 13.11.8. Production does wait for a manual release decision. | 13.11.8 |

## Link to requirements

Availability QR, and the survey: respondents accept planned outages but not lost work.

## Decisions and trade offs

* **Rolling instead of blue green:** no live colour to track, safe when a deploy fails halfway, and both instances serve traffic. Trade off: rollback means redeploying the previous SHA.
* **No feature flags:** see above. Trade off: a feature is either released to everyone or not at all.

## Problems we ran into

* **Port clash on the first deploy:** the old single frontend held the port `frontend-a` needed, so `frontend-b` goes first.
* **Banner test showed nothing:** the tab was opened before the deploy that added the banner.
* **Compose file errors only show on the server:** we now validate it with `docker compose config --quiet` first.

## What we learned

### Emad

* **Could not do at the start, can do now:** [TO FILL]
* **Would do differently next time:** [TO FILL]
* **Already knew before this course:** [TO FILL]

### Andrea

* **Could not do at the start, can do now:** [TO FILL]
* **Would do differently next time:** [TO FILL]
* **Already knew before this course:** [TO FILL]

## Use of generative AI

Claude helped compare rolling and blue green updates and write the deploy script. This document was drafted with Claude from our own project notes and checked by us.
